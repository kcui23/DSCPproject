#' Plots for textual data
#' 
#' The `textplot_*()` functions formerly in \pkg{quanteda} have now been moved 
#' to the \pkg{quanteda.textplots} package.
#' @name textplots
#' @seealso `quanteda.textplots::quanteda.textplots-package`
NULL
